package eportfolio;
import javax.swing.*;  
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.event.KeyEvent;


 class Portfolio extends JFrame implements ActionListener, WindowListener    //GUI start
 {
    private Investments data;
    private JPanel usepanel = new HomePanel();
    public static final int WIDTH = 700;
    public static final int HEIGHT = 400;
    private JComboBox type1 = new JComboBox(new Object[]{"Buy", "Sell", "Update", "Get Gain", "Search", "Quit"});

    public void Removal()
    {
        remove(usepanel);
    }

    public void Packer()
    {
        pack();
    }


    Portfolio(Investments data) 
     {
        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
        add(BorderLayout.NORTH, inputPanel);     
        setTitle("Investment Manager");      //Heading
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //exit method

        addWindowListener(this);
        this.data = data;


        inputPanel.add(new JLabel("Options"));   //options label
        inputPanel.add(type1);

        JButton buy = new JButton("Buy");  //buy label
        inputPanel.add(buy);
        buy.addActionListener(this);    

        JButton sell = new JButton("Sell");  //sell label
        inputPanel.add(sell);
        sell.addActionListener(this);

        JButton update = new JButton("Update");  //update label
        inputPanel.add(update);
        update.addActionListener(this);

        JButton getGain = new JButton("Get Gain");  //get gain label
        inputPanel.add(getGain);
        getGain.addActionListener(this);

        JButton search = new JButton("Search");  //search label
        inputPanel.add(search);
        search.addActionListener(this);

        JButton quit = new JButton("Quit");  //quit label
        inputPanel.add(quit);
        quit.addActionListener(this);

        add(BorderLayout.CENTER, usepanel);  
    }

    private void buy() 
    {
        Removal();   //remove previous welcome message
        usepanel = new BuyPanel();  //display buy UI
        add(BorderLayout.CENTER, usepanel);
        Packer();
    }

    private void sell()
    {
        Removal();
        usepanel = new SellPanel();   //display sell UI
        add(BorderLayout.CENTER, usepanel);
        Packer();
    }


    private void update()
    {
        Removal();
        usepanel = new UpdatePanel();  //display update UI
        add(BorderLayout.CENTER, usepanel);
        Packer();
    }

    private void getGain() 
    {
        Removal();
        usepanel = new GetGainPanel();  //display getgain UI
        add(BorderLayout.CENTER, usepanel);
        Packer();
    }

    private void search() 
    {
        Removal();
        usepanel = new SearchPanel();   //display search UI
        add(BorderLayout.CENTER, usepanel);
        Packer();
    }

    private void quit()   
    {        
        setVisible(false);   
        dispose();
    }

    @Override   //remove redundancy
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getActionCommand().equalsIgnoreCase("Buy")) 
        {
            buy();
        } 
        else if (e.getActionCommand().equalsIgnoreCase("Sell")) 
        {
            sell();
        } 
        else if (e.getActionCommand().equalsIgnoreCase("Update")) 
        {
            update();
        } 
        else if (e.getActionCommand().equalsIgnoreCase("Get Gain")) 
        {
            getGain();
        } 
        else if (e.getActionCommand().equalsIgnoreCase("Search")) 
        {
            search();
        } 
        else if (e.getActionCommand().equalsIgnoreCase("Quit")) 
        {
            quit();
        }
       /* if (e.getActionCommand().equalsIgnoreCase("Options")) 
        {
            options();
        }*/
    }

    
   @Override
    public void windowClosing(WindowEvent e) 
    {
    }

    @Override
    public void windowOpened(WindowEvent e) 
    {
    }

    @Override
    public void windowClosed(WindowEvent e) 
    {
    }

    @Override
    public void windowIconified(WindowEvent e) 
    {
    }

    @Override
    public void windowDeiconified(WindowEvent e) 
    {
    }

    @Override
    public void windowActivated(WindowEvent e) 
    {
    }

    @Override
    public void windowDeactivated(WindowEvent e) 
    {
    }

    private class HomePanel extends JPanel    //welcome message
    {
        public HomePanel()
        {
            setLayout(new BorderLayout());
            add(BorderLayout.NORTH, new JLabel("<html>Greetings! This is an Investment Manager.Please select a command from the \"Commands\" menu</html>"));
        }
    }

    private class BuyPanel extends JPanel implements ActionListener    //Buy GUI
    {
        private JTextArea msgs = new JTextArea();          
        private JComboBox type1 = new JComboBox(new Object[]{"Stock", "Mutual Fund"}); //dropdown menu
        private JTextField symbolField = new JTextField();
        private JTextField nameField = new JTextField();
        private JTextField quantityField = new JTextField();
        private JTextField priece1 = new JTextField();

        public BuyPanel()    //creating labels and buttons for Buy
        {
            setLayout(new BorderLayout());
            JPanel inputPanel = new JPanel(new GridLayout(5, 2));
            add(BorderLayout.CENTER, inputPanel);
            JPanel messagesPanel = new JPanel(new BorderLayout());
            add(BorderLayout.NORTH, messagesPanel);
            JPanel buttonsPanel = new JPanel(new FlowLayout());
            add(BorderLayout.SOUTH, buttonsPanel);
            JButton resetButton = new JButton("Reset");
            JButton buy = new JButton("Buy");
            
            messagesPanel.add(BorderLayout.CENTER, new JScrollPane(msgs));

            inputPanel.add(new JLabel("Type"));   //type label


            inputPanel.add(type1);
            
            
            inputPanel.add(new JLabel("Symbol"));   //symbol label
            
            
            inputPanel.add(symbolField);
            
            
            inputPanel.add(new JLabel("Name")); //name label
            
            
            inputPanel.add(nameField);
            
            
            inputPanel.add(new JLabel("Quantity"));  //quantity label
            
            
            inputPanel.add(quantityField);
            
            
            inputPanel.add(new JLabel("Price"));  //price label
            
            
            inputPanel.add(priece1);     /*Adding buttons to the GUI*/
            
            
            resetButton.addActionListener(this);
            
            
            buy.addActionListener(this);
            
            
            buttonsPanel.add(resetButton);
            
            
            buttonsPanel.add(buy);
        }

        private void buy()    //buy working logic
        {
            int quantity;
            double price;
            String symbol = new String();
            Investment investment = data.searchInvestment(symbol);
            String name = new String();
            String str1 = new String();
            String strPrice = new String();

            symbol = symbolField.getText();
            name = nameField.getText();
            str1 = quantityField.getText();
            strPrice = priece1.getText();

            if(symbol.isEmpty() == true)
            {
                msgs.setText("Symbol cannot be empty");
                return;
            }
            else if(name.isEmpty() == true)
            {
                msgs.setText("Name cannot be empty");
                return;
            }
            else if(str1.isEmpty() == true)
            {
                msgs.setText("Quantity cannot be empty");
                return;
            }
            else if(strPrice.isEmpty() == true)
            {
                msgs.setText("Price cannot be empty");
                return;
            }

            quantity = Integer.parseInt(str1);
            if(quantity == 0)
            {
                msgs.setText("Quantity cannot be zero!");
                return;
            }
            else if(quantity < 0)
            {
                msgs.setText("Quantity cannot be negative!");
                return;
            }


            price = Double.parseDouble(strPrice);
            if(price == 0)
            {
                msgs.setText("Price cannot be zero!");
                return;
            }
            else if(price < 0)
            {
                msgs.setText("Price cannot be negative!");
                return;
            }

                                      //if investment does not exist
            if (investment == null)                     //stock investment
            {
             if (type1.getSelectedItem().toString().equals("Stock")==true)              
             {
                 investment = new Stock(symbol, name, quantity, price);
             } 
             else if (type1.getSelectedItem().toString().equals("Mutual Fund")==true)  //mutual fund investment
             {
                 investment = new MutualFund(symbol, name, quantity, price);
             }
             else
             {}
             msgs.setText("New investment added.");
             data.addInvestment(investment);
             /*  investments.add(investment);
        Scanner sc3 = new Scanner(investment.getName());

        while (sc3.hasNext()) 
        {
            String word = new String();
            word = sc3.next().toLowerCase();
            if (keywordsMapping.containsKey(word) == false) 
            {
                keywordsMapping.put(word, new ArrayList<>());
            }

            keywordsMapping.get(word).add(investment);
        }*/
            } 
            else if(investment != null)  //investment does not exist
            {
            investment.buy(quantity, price);
            investment.setPrice(price);
            msgs.setText("This investment already exists! Quantity updated!");
            }
            else
            {}
        }

        @Override
        public void actionPerformed(ActionEvent e) 
        {
            if (e.getActionCommand().equalsIgnoreCase("Buy")==true) 
            {
                buy();
            }
            else
            {
            }
        }
    }

    private class SellPanel extends JPanel implements ActionListener //sell an investment 
    {
        private JTextArea msgs = new JTextArea();
        private JTextField symbolField = new JTextField();
        private JTextField quantityField = new JTextField();
        private JTextField priece1 = new JTextField();

        public SellPanel()       //GUI of sell an investment
        {
            setLayout(new BorderLayout());
            JPanel messagesPanel = new JPanel(new BorderLayout());
            JPanel buttonsPanel = new JPanel(new FlowLayout());
            JButton resetButton = new JButton("Reset");
            JButton sell = new JButton("Sell");
            JPanel inputPanel = new JPanel(new GridLayout(3, 2));
            
            add(BorderLayout.CENTER, inputPanel);
            inputPanel.add(new JLabel("Symbol"));
            resetButton.addActionListener(this);
            inputPanel.add(symbolField);
            add(BorderLayout.NORTH, messagesPanel);
            add(BorderLayout.SOUTH, buttonsPanel);
            inputPanel.add(new JLabel("Quantity"));
            buttonsPanel.add(resetButton);
            buttonsPanel.add(sell);
            sell.addActionListener(this);
            inputPanel.add(quantityField);
            messagesPanel.add(BorderLayout.CENTER, new JScrollPane(msgs));
            inputPanel.add(new JLabel("Price"));
            inputPanel.add(priece1);
        }

        private void sell()  //working mechanism of Sell
        {
            int quantity;
            double price;
            double soldAmount;
            String symbol = new String();
            String str1 = new String();
            String strPrice = new String();

            symbol = symbolField.getText();
            Investment investment = data.searchInvestment(symbol);
            str1 = quantityField.getText();
            strPrice = priece1.getText();

            if(symbol.isEmpty() == true)
            {
                msgs.setText("Symbol cannot be empty");
                return;
            }
            else if(str1.isEmpty() == true)
            {
                msgs.setText("Quantity cannot be empty");
                return;
            }
            else if(strPrice.isEmpty() == true)
            {
                msgs.setText("Price cannot be empty");
                return;
            }
            quantity = Integer.parseInt(str1);
            price = Double.parseDouble(strPrice);

            if (investment != null)  //if the investment does not exist
            {
                if (quantity > investment.getQuantity()) 
                {
                    msgs.setText("Quantity to sell cannot be more than the present quantity");
                    return;
                }
            }
            else if(investment == null) //if the investment exists
            {
                msgs.setText("The investment does not exist!");
                return;
            }
            else
            {}
                investment.setPrice(price);
                soldAmount = investment.sell(quantity, price);
                msgs.setText("SOLD!");
                if (investment.getQuantity() == 0)   //if the noew available auntity is zero
                {
                    data.removeInvestment(investment);  
                    /*
                     investments.remove(investment);
        Scanner sc4 = new Scanner(investment.getName());

        while (sc4.hasNext()) 
        {
            String word = new String();
            word = sc4.next().toLowerCase();

            if (keywordsMapping.containsKey(word)) 
            {
                keywordsMapping.get(word).remove(investment);
            }
        }
    } */ 
                    msgs.append("\nThe investment has been deleted as new available quantity is zero!");
                }
                else
                {}
            
        }

        @Override                           //remove redundancy
        public void actionPerformed(ActionEvent e) 
        {
            if (e.getActionCommand().equalsIgnoreCase("Sell")==true) 
            {
                sell();
            }
            else
            {}
        }
    }

    private class UpdatePanel extends JPanel implements ActionListener    //update an investment
    {
        private JButton next = new JButton("Next");
        private JButton previous = new JButton("Previous");
        private JTextField priece1 = new JTextField();
        private JTextField nameField = new JTextField();
        private JTextField symbolField = new JTextField();
        private JTextArea msgs = new JTextArea();
        private JButton save = new JButton("Save");

        public UpdatePanel()                            //GUI for update (adding buttons and labels)
        {
            setLayout(new BorderLayout());

            JPanel inputPanel = new JPanel(new GridLayout(3, 2));
            JPanel messagesPanel = new JPanel(new BorderLayout());
            JPanel buttonsPanel = new JPanel(new FlowLayout());
            messagesPanel.add(BorderLayout.CENTER, new JScrollPane(msgs));
            add(BorderLayout.CENTER, inputPanel);
            add(BorderLayout.NORTH, messagesPanel);
            add(BorderLayout.SOUTH, buttonsPanel);
            previous.addActionListener(this);
            next.addActionListener(this);
            save.addActionListener(this);
            buttonsPanel.add(previous);
            buttonsPanel.add(next);
            buttonsPanel.add(save);

            inputPanel.add(new JLabel("Name"));
            inputPanel.add(nameField);
            inputPanel.add(new JLabel("Price"));
            inputPanel.add(priece1);
            inputPanel.add(new JLabel("Symbol"));
            inputPanel.add(symbolField);
        }

        @Override                               //remove redundancy
        public void actionPerformed(ActionEvent e) 
        {
            if (e.getActionCommand().equalsIgnoreCase("Previous")) 
            {
            } 
            else if (e.getActionCommand().equalsIgnoreCase("Next")) 
            {
            } 
            else if (e.getActionCommand().equalsIgnoreCase("Save")) 
            {
            }
        }
    }

    private class GetGainPanel extends JPanel     //getgain for all investments
    {

        public GetGainPanel() 
        {
        }
    }

    private class SearchPanel extends JPanel implements ActionListener    //search for an investment
    {
        private JTextField keywordsField = new JTextField();
        private JTextField symbolField = new JTextField();
        private JTextField lowPriceField = new JTextField();
        private JTextField highPriceField = new JTextField();
        private JTextArea msgs = new JTextArea();

        public SearchPanel()                                  //GUI for search (adding buttons and labels)
        {
            setLayout(new BorderLayout());

            JButton resetButton = new JButton("Reset");
            resetButton.addActionListener(this);
            JButton search = new JButton("Search");
            search.addActionListener(this);
            JPanel inputPanel = new JPanel(new GridLayout(4, 2));
            add(BorderLayout.CENTER, inputPanel);
            JPanel messagesPanel = new JPanel(new BorderLayout());
            JPanel buttonsPanel = new JPanel(new FlowLayout());
            add(BorderLayout.SOUTH, messagesPanel);
            add(BorderLayout.EAST, buttonsPanel);

            buttonsPanel.add(resetButton);
            buttonsPanel.add(search);

            messagesPanel.add(BorderLayout.CENTER, new JScrollPane(msgs));

            inputPanel.add(new JLabel("Name Keywords"));
            inputPanel.add(keywordsField);

            inputPanel.add(new JLabel("Symbol"));
            inputPanel.add(symbolField);

            inputPanel.add(new JLabel("Lower Price"));
            inputPanel.add(lowPriceField);

            inputPanel.add(new JLabel("Higher Price"));
            inputPanel.add(highPriceField);
        }

        private void search()                   //working mechanism for searching an investment
        {
            double lowPrice = 0, highPrice = 0;
            
            String strLowPrice = new String();
            strLowPrice = lowPriceField.getText();
            if (strLowPrice.isEmpty() == false) 
            {
                    lowPrice = Double.parseDouble(strLowPrice);    
            }
            else if (strLowPrice.isEmpty() != false) 
            {
            }

            String strHighPrice = new String();
            strHighPrice = highPriceField.getText();
            if (strHighPrice.isEmpty() == false) 
            {
                    highPrice = Double.parseDouble(strHighPrice);
            } 
            else if(strHighPrice.isEmpty() != false)
            {
            }

            if ((lowPrice < highPrice)==false) 
            {
                msgs.setText("Incorrect price values entered!");
                return;
            }

            String symbol = new String();
            symbol = symbolField.getText();
            String keywords = new String();
            keywords = keywordsField.getText();

            ArrayList<Investment> investments = data.searchInvestments(symbol, keywords, lowPrice, highPrice);

            int i = 1;
            for (Investment investment : investments) 
            {
                msgs.setText("Result"+i+":");
                msgs.append("\n" + investment.toString() + "\n");
                i++;
            }
        }

        @Override                      //remove redundancy
        public void actionPerformed(ActionEvent e) 
        {
        if (e.getActionCommand().equalsIgnoreCase("Search")) 
        {
            search();
        }
        }
    }
}

 abstract class Investment      //handling all the investments
 {
    private String symbol;
    private String name;
    private double price=0;

    protected int quantity=0;
    protected double bookValue=0;
    
    Investment(String symbol, String name, double price) 
    {
        this.symbol = symbol;  //investment symbol
        this.name = name;    //investment name
        this.price = price;  //investment price
    }

    @Override
    public String toString() 
    {
        return "Symbol: " + getSymbol() + "\n" + "Name: " + getName() + "\n" + "Quantity: " + getQuantity() + "\n" + "Price: $" + String.format("%,.2f", getPrice()) + "\n" + "Book value: $" + String.format("%,.2f", getBookValue()) + "\n" + "Gain: $" + String.format("%,.2f", calculateGain());
    }

    public abstract void buy(int quantity, double buying_price);  //buy the quantity of the investment
    public abstract double sell(int quantity, double buying_price);   ////sell the quantity of the investment
    public abstract double calculateGain();   //calculating the gain from the investment

    public String getSymbol() //return investment symbol
    {
        return symbol;
    }

    public String getName() //return investment name
    {
        return name;
    }

    public int getQuantity()  //return investment quantity
    {
        return quantity;
    }

    public double getPrice() //return investment price
    {
        return price;
    }

    public double getBookValue() //return book value
    {
        return bookValue;
    }

    public void setPrice(double price) //set a new price
    {
        this.price = price;
    }
}

 class Stock extends Investment 
 {

     //create a mutualfund investment
    Stock(String symbol, String name, int quantity, double price) 
    {
      super(symbol, name, price);
      buy(quantity,price);
    }
    
    @Override
    public void buy(int n, double buyingPrice) //buy the quantity of the mutualfund investment
    {
        if ((n < 0) || (n==0) || (buyingPrice < 0)) //return if the qunatity to buy is zero or neagtive
        {
            return;
        }

        bookValue = (getQuantity() * getPrice() + 9.99);  //calculating the book value
        quantity = quantity + n;
    }

    @Override
    public double sell(int sellQuantity, double sellingPrice)   //sell the quantity of the stock investment
    {
        double sellAmount = 0;
        int oldQuantity =0;

        if ((sellQuantity <= 0) || (sellQuantity > quantity) || sellingPrice<0) //return if selling quantity is negative or zero or more than the quantity bought
        {
            return 0;
        }
       
        sellAmount = sellQuantity * getPrice() - 9.99;

        oldQuantity = quantity;   // update the quantity
        quantity = quantity - sellQuantity;
      
        bookValue = bookValue * ((double) quantity / (double) oldQuantity);  // update the book value  

        return sellAmount;
    }

    @Override
    public double calculateGain()   //calculate the gain of stock
    {
        double today = 0;
        today = ((quantity * getPrice()) - 9.99);
        return today - bookValue;
    }

    @Override
    public String toString() 
    {
        return "Type: Stock" + "\n" + super.toString();
    }
}

 class MutualFund extends Investment 
 {
     //create a mutualfund investment
     MutualFund(String symbol, String name, int quantity, double price) 
     {
         super(symbol, name, price);
         buy(quantity,price);
     }

     @Override
     public void buy(int n, double buyingPrice)    //buy the quantity of the mutualfund investment
     {
         if ((n < 0) || (n==0) || (buyingPrice<0)) //return if the qunatity to buy or price is zero or neagtive
         {
             return;
         }
 
         bookValue = (getQuantity() * getPrice());  //calculating the book value
         quantity = quantity + n;
     }

     @Override
     public double sell(int sellQuantity, double sellingPrice) //sell the quantity of the mutualfund investment
     {
         double sellAmount = 0;
         int oldQuantity =0;
 
         if ((sellQuantity <= 0) || (sellQuantity > quantity) || (sellingPrice < 0))  //return if selling quantity is negative or zero or more than the quantity bought
         {
             return 0;
         }
 
         sellAmount = sellQuantity * getPrice() - 45;
 
         oldQuantity = quantity;  // update the quantity
         quantity = quantity - sellQuantity;   
        
         bookValue = bookValue * ((double) quantity / (double) oldQuantity);  // update the book value 
 
         return sellAmount;
     }

    public double calculateGain() 
    {
        double today2 = 0;
        today2 = ((quantity * getPrice()) - 45);
        return today2 - bookValue;
    }

    @Override
    public String toString() 
    {
        return "Type: Mutual Fund" + "\n" + super.toString();
    }
}

class Investments
{
    ArrayList<Investment> investments = new ArrayList<>();
    static HashMap <String, ArrayList<Investment>> keywordsMapping = new HashMap<>();     // We need a hashmap to map keywords to an investment for easy searching

    public Investment searchInvestment(String symbol) 
    {
        for (Investment investment : investments) 
        {
            if (investment.getSymbol().equalsIgnoreCase(symbol)) 
            {
                return investment;
            }
        }

        return null;
    }

    private static boolean searchwords(String word, Investment investment) //checking if the keywords can be found in the investment
    {                                                 
        Scanner sc2 = new Scanner(word);

        while (sc2.hasNext()) 
        {
            String words = new String();
            words = sc2.next().toLowerCase();

            if (keywordsMapping.containsKey(words)==false) //return false if word does not match
            {
                return false;
            }

            if (keywordsMapping.get(words).contains(investment)==false) //return false if word does not match
            {
                return false;
            }
        }

        return true;   //return true if the word matched
    }

     ArrayList<Investment> searchInvestments(String symbol, String keywords, double min, double max) 
     {
        ArrayList<Investment> Investment2 = new ArrayList<>();
        ArrayList<Investment> Investment1 = new ArrayList<>();

        
        if (symbol.isEmpty() == true)   // filter by symbol
        {
            Investment2.addAll(investments);
        } 
        else if(symbol.isEmpty() == false)
        {
            for (Investment investment : investments) 
            {
                if (symbol.equalsIgnoreCase(investment.getSymbol())) 
                {
                    Investment2.add(investment);
                }
            }
        }
        
        if (keywords.isEmpty() == true)   // filter by keyword
        {
            Investment1.addAll(Investment2);
        } 
        else if(keywords.isEmpty() == false)
        {
            for (Investment investment : Investment2) 
            {

                if (searchwords(keywords, investment)) 
                {
                    Investment1.add(investment);
                }
            }
        }

        Investment2.clear();
        Investment2.addAll(Investment1);
        Investment1.clear();

        for (Investment investment : Investment2) //filter by price
        {
            if ((investment.getPrice() > min || investment.getPrice() == min) && (investment.getPrice() == max || investment.getPrice() < max))
            {
                Investment1.add(investment);
            }
        }

        Investment2.clear();
        Investment2.addAll(Investment1);
        return Investment2;
    }

    public void addInvestment(Investment investment)        //add an investment to the portfolio
    {
        investments.add(investment);
        Scanner sc3 = new Scanner(investment.getName());

        while (sc3.hasNext()) 
        {
            String word = new String();
            word = sc3.next().toLowerCase();
            if (keywordsMapping.containsKey(word) == false) 
            {
                keywordsMapping.put(word, new ArrayList<>());
            }

            keywordsMapping.get(word).add(investment);
        }
    }

    public void removeInvestment(Investment investment)    //remove an investment from the portfolio
    {
        investments.remove(investment);
        Scanner sc4 = new Scanner(investment.getName());

        while (sc4.hasNext()) 
        {
            String word = new String();
            word = sc4.next().toLowerCase();

            if (keywordsMapping.containsKey(word)) 
            {
                keywordsMapping.get(word).remove(investment);
            }
        }
    }

}

public class ePortfolio 
{
    public static void main(String[] args) 
    {
        Investments data = new Investments();
        Portfolio frame = new Portfolio(data);
        frame.setVisible(true);
    }

}


