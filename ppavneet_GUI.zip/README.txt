1.The general problem that is being solved:
  
This program simplifies and keeps record of different investments that a user make using a GUI.
For example it can;
- Track the investment a user buys, which includes keeping record of its name, symbol, price and quantity
- Sell a specific amount of investment that the user has
- Update the price of an existing investment
- Calculate the total amount a user gained from their investment
- Search a specific investment 

2. Assumptions and limitations:

Assumption => The program works with two kinds of investments (Stock and MutualFund)
           => Buying quantity cannot be negative
Limitation => The program can only handle 2 types of investment
           => The program might crash if invalid values are entered
           => Search and GetGain are incomplete

3.User guide:

The program can be complied using the following command on terminal:

javac ePortfolio.java
javac -d . ePortfolio.java

The program runs using the following command on terminal:
  
java eportfolio.ePortfolio 

4.Correctness of the program (Test Plan):

The program can be tested by providing various inputs, for example those mentioned in the assignment pdf. The correctness has been tested by me using different values. 
For example;

=> If the user bought 300 shares of APPLE stock at the price of $100.01 per share, the bookValue should be 300*100.01+9.99 = $30,012.99.
   If the user later updates the price to $102.01 per share. Then the gain will be (300*102.01-9.99)-30,012.99 = $580.02
   If the user sells 50 shares at $102.01 per share, the amount recieved will be $5090.51.
   The program will update the new quantity of shares to 300-50 = 250 shares and bookValue to 30,012.99*50/300 = $5002.165
   Supposedly if the user sells all 250 shares, the new quantity of share will be updated to zero and the investment will be deleted from the record.

=> If the user bought 300 units of SAMSUNG mutualfund at the price of $50.7 per unit, the bookValue should be 300*50.7 = $15,210.
   If the user later updates the price to $45 per unit. Then the loss will be (300*45-45)-15,210 = $1,755.
   If the user sells 50 units at $45 per unit, the payment recieved will be 50*45-45= $2,205, the new quantity of units will be updated to 250 units and bookValue will be updated to 15,210*50/300 = $2,535.
   Supposedly if the user sells all 250 shares, the new quantity of share will be updated to zero and the investment will be deleted from the record.

=> If we initially buy 500 shares of AAPL stock at the price of $110.08 per share, the 
quantity will be 500, and the bookValue will be 500 × 110.08 + 9.99 = $55,049.99.   Later on, if 
the price is changed to $142.23 per share, the gain will be (500 × 142.23 – 9.99) – 55,049.99 = 
71,105.01 – 55,049.99 = $16,055.02.  Alternatively,  if we sell 200 shares of this stock at 
$142.23 per share, the payment received will be 200 × 142.23 – 9.99 = $28,436.01, the quantity 
will be reduced to 300, and bookValue will be adjusted to 55,049.99 × 300/500 = $33,029.99.

=>  if we initially 
buy 450 units of SSETX at $53.26 per unit, the quantity will be 450 and the bookValue will be 
450 × 53.26 = $23,967.00.   Later on, if the price goes down to $42.21 per unit, the gain will be 
(450 × 42.21 – 45.00) – 23,967.00 = 18,949.50 – 23,967.00 = –$5,017.50.  Alternatively, if we 
sell 150 units of this fund at $42.21 per unit, the payment received will be 150 × 42.21 – 45.00 = 
$6,286.50, the quantity will be reduced to 300, and the bookValue will be changed to 23,967.00 
×300/450 = $15,978.00. 

5.Possible improvements that could be done:

The program could be more efficient and flexible in dealing with different cases of possible errors. 
